from django.shortcuts import render, redirect
from .models import Todoitem
# Create your views here.


def todo(request):
    all_items = Todoitem.objects.all()
    return render(request, 'todo.html', {'all_items': all_items})


def addtodo(request):
    new_item = Todoitem(content=request.POST['content'])
    new_item.save()
    return redirect('todo')


def deletetodo(request, todo_id):
    delete_item = Todoitem.objects.get(id=todo_id)
    delete_item.delete()
    return redirect('todo')
