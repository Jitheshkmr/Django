from django.shortcuts import render
import requests
from .models import City

# Create your views here.


def weather(request):
    url = 'http://api.openweathermap.org/data/2.5/weather?q={}&units=imperial&appid=xxxxx'
    citys = City.objects.all()

    weather_list=[]

    for city in citys:

        r = requests.get(url.format(city)).json()
        # print(r.text)

        city_weather = {
            'city': city,
            'temp': r['main']['temp'],
            'desc': r['weather'][0]['description'],
            'icon': r['weather'][0]['icon'],
        }
        # print(city_weather)
        weather_list.append(city_weather)

    # print(weather_list)
    context = {'weather_list': weather_list}

    return render(request, 'weather.html', context)
